<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\directorio;
use App\Models\contactos;

class directorioController extends Controller
{
    //
    public function MostrarDirectorio(){
        $directorio = directorio::all();
        return view('directorio',compact('directorio'));
    }

    public function create(){
        return view('crearEntrada');
    }

    public function store(Request $request){

        $directorio = new directorio;
        $directorio->codigoEntrada =$request->input('codigo');
        $directorio->nombre =$request->input('nombre');
        $directorio->apellido =$request->input('apellido');
        $directorio->correo =$request->input('correo');
        $directorio->telefono =$request->input('telefono');

        $directorio->save();
        
        return $this->MostrarDirectorio();
    }

    public function BuscarEntrada(){
        return view('buscar');
    }

    public function delete($id){
        //Encontradno directorio a eliminar
        $directorio = directorio::find($id);
        return view('eliminar',compact('directorio'));
    }

    public function destroy($id){
        $contactos = contactos::where('codigoEntrada',$id);
        $directorio = directorio::find($id);
        
        //Eliminando los contactos del directorio 
        foreach($contactos as $contacto){
            $contacto->delete();
        }
        //Eliminando directorio 
        $directorio->delete();

        return $this->MostrarDirectorio();
    }

    public function BuscarDirectorio(Request $request){
        
        {
            $correo = $request->input('correo');
            
            $resultado = Directorio::where('correo', $correo)->first();
            
            if ($resultado) {
                $codigoEntrada = $resultado->codigoEntrada;
                $directorio = directorio::find($codigoEntrada);
                $contactos = contactos::where('codigoEntrada',$codigoEntrada)->get();
                return view('vercontactos', compact('contactos','directorio'));
            } 
            
        }
        
        
    }
}

